from gui.main_window import launch_app

if __name__ == '__main__':
    launch_app()